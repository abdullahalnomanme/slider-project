
(function ($){
	"use strict";
	jQuery(document).ready(function($){
		$(".embed-responsive iframe").addClass(".embed-responsive item");
		$(".carousel-inner .item:first-child").addClass("active");

	$(".homepage-slides").owlCarousel({
			items:1,
			autoplay:false,
			loop:true,
			nav:true,
			dots:false,
			
		});

	});

	jQuery(window).load(function(){

	});

}(jQuery));

